import openai
import json
import streamlit as st
import requests
from bs4 import BeautifulSoup

def get_text_from_url(url):
    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, "html.parser")
    # Clean the text
    text = soup.get_text(separator=" ").strip()
    return text

def extract_with_llm(text_or_url):
    # If it's a URL, fetch the text first
    if text_or_url.startswith("http"):
        text = get_text_from_url(text_or_url)
    else:
        text = text_or_url
        
    client = openai.OpenAI(api_key=st.secrets["OPENAI_API_KEY"])
    
    prompt = f"""
    Analyze the following Job Description. Extract certifications and key skills.
    Return ONLY a valid JSON object in this format: 
    {{"certs": [{{"name": "Certification Name", "level": "Required/Preferred"}}, ...]}}
    
    Job Description: {text[:5000]}
    """
    
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        response_format={"type": "json_object"}
    )
    
    data = json.loads(response.choices[0].message.content)
    return data.get("certs", [])