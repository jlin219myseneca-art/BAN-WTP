from scraper import extract_from_html, fetch_url
import streamlit as st
import pandas as pd
import sqlite3
import plotly.express as px
from db_utils import init_db, save_job_data
from scraper import extract_from_html


# Initialize DB
init_db()

st.set_page_config(page_title="Strategic Training Insights", layout="wide")
st.title("🎓 Certification & Skill Strategic Insights")

# --- SIDEBAR MANAGEMENT ---
with st.sidebar:
    st.title("🛠️ Navigation")
    
    # Using a modern radio button styled with a bit of a gap
    choice = st.radio(
        "Go to:",
        ["📈 Dashboard", "📥 Batch Import"],
        captions=["Analytics & Insights", "Upload New Data"]
    )


    st.markdown("---")
    st.subheader("Data Management")
    if st.button("⚠️ Clear All Data"):
        conn = sqlite3.connect("job_market_research.db")
        conn.execute("DELETE FROM requirements")
        conn.execute("DELETE FROM jobs")
        conn.commit()
        conn.close()
        st.success("Database cleared!")
        st.rerun()


# --- BATCH IMPORT LOGIC ---
if choice == "📥 Batch Import":
    st.header("Import Job Description")
    url_input = st.text_input("Enter URL (Optional):")
    html_manual = st.text_area("Or paste manual HTML/Text here:")
    
    if st.button("Process"):
        final_content = ""
        
        # Priority 1: Try URL
        if url_input:
            success, content = fetch_url(url_input)
            if success:
                final_content = content
                st.success("Successfully scraped via URL!")
            else:
                st.warning(f"URL Scraping failed: {content}. Please paste manually below.")
                final_content = html_manual
        else:
            final_content = html_manual
            
        # If we have content (either from URL or Manual), process it
        if final_content and len(final_content) > 50:
            certs = extract_from_html(final_content)
            unique_job_id = f"JD_{pd.Timestamp.now().strftime('%Y%m%d%H%M%S')}"
            job_record = {"job_id": unique_job_id, "title": "Job Posting", "url": url_input or "Manual"}
            
            save_job_data(job_record, certs)
            st.success("Data processed and saved to database!")
        else:
            st.error("No content provided or extracted.")

        if final_content and len(final_content) > 50:
                    certs = extract_from_html(final_content)
                    st.write(f"DEBUG: Found these certs: {certs}") # ADD THIS LINE
                    
                    if not certs:
                        st.warning("The scraper ran, but didn't find any keywords from your CERT_REGEX list.")         

# --- DASHBOARD & ANALYTICS ---
elif choice == "📈 Dashboard":
    conn = sqlite3.connect("job_market_research.db")
    query = "SELECT r.certification, j.date_scraped FROM requirements r LEFT JOIN jobs j ON r.job_id = j.job_id"
    df = pd.read_sql(query, conn)
    conn.close()
    
    if not df.empty:
        df['date_scraped'] = pd.to_datetime(df['date_scraped'])
        
        # --- SIDEBAR FILTERS ---
        st.sidebar.markdown("---")
        st.sidebar.subheader("Time Analysis")
        time_res = st.sidebar.radio("Group By:", ["Month", "Quarter", "Year"])
        
        # Define resolution
        res_map = {"Month": "M", "Quarter": "Q", "Year": "Y"}
        df['period'] = df['date_scraped'].dt.to_period(res_map[time_res]).astype(str)
        
        # --- DASHBOARD CONTENT ---

        
        # 1. Summary Table
        summary = df['certification'].value_counts().reset_index()
        summary.columns = ['Certification/Skill', 'Total Mentions']
        
        st.subheader("Executive Summary")
        st.table(summary)

        # 2. Total Demand Distribution
        st.subheader("Total Demand Distribution")
        fig_bar = px.bar(
            summary, 
            x='Total Mentions', 
            y='Certification/Skill', 
            orientation='h', 
            color='Certification/Skill', # Color by name makes it look much better
            template="plotly_white",
            color_discrete_sequence=px.colors.qualitative.Pastel
        )
        fig_bar.update_layout(showlegend=False) # Remove legend to save space
        st.plotly_chart(fig_bar, use_container_width=True)

        # 3. Strategic Insight
        st.subheader("Strategic Recommendations")
        top_skill = summary.iloc[0]['Certification/Skill']
        st.write(f"💡 **Key Insight:** **{top_skill}** is the leading skill request.")
        

        # 3. Trend Chart - Side-by-side comparison
        with st.expander("📈 View Demand Trends over Time (Click to expand)"):
            # Only calculate if we have data
            trend_data = df.groupby(['period', 'certification']).size().reset_index(name='count')
            trend_data['period'] = trend_data['period'].astype(str)
            
            fig_trend = px.bar(
                trend_data, 
                x='period', 
                y='count', 
                color='certification',
                barmode='group',
                template="plotly_white", # Light background is much easier on the eyes
                color_discrete_sequence=px.colors.qualitative.Pastel # Muted colors
            )
            fig_trend.update_traces(marker_line_color='white', marker_line_width=1.5)
            fig_trend.update_xaxes(type='category')
            st.plotly_chart(fig_trend, use_container_width=True)

        # 4. Export
        st.download_button("Download Data", df.to_csv(index=False), "market_data.csv", "text/csv")
    else:
        st.info("No data found.")
       
       