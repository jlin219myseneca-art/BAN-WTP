import sqlite3
import pandas as pd

DB_NAME = "job_market_research.db"

def get_connection():
    return sqlite3.connect(DB_NAME)

def init_db():
    conn = get_connection()
    conn.execute("""
    CREATE TABLE IF NOT EXISTS jobs (
        job_id TEXT PRIMARY KEY,
        job_title TEXT,
        organization TEXT,
        url TEXT UNIQUE,
        source_type TEXT,
        date_scraped DATETIME DEFAULT CURRENT_TIMESTAMP
    );""")
    conn.execute("""
    CREATE TABLE IF NOT EXISTS requirements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id TEXT,
        certification TEXT,
        requirement_level TEXT,
        FOREIGN KEY (job_id) REFERENCES jobs(job_id)
    );""")
    conn.commit()
    conn.close()

def save_job_data(job_record, cert_list):
    with get_connection() as conn:
        # 1. ALWAYS ensure the job exists. 
        # Using INSERT OR REPLACE ensures that if the ID exists, it updates; if not, it creates.
        conn.execute("INSERT OR REPLACE INTO jobs (job_id, job_title, url) VALUES (?, ?, ?)", 
                     (job_record['job_id'], job_record['title'], job_record['url']))
        
        # 2. Add requirements
        for cert in cert_list:
            # Added a default for requirement_level to avoid database errors
            level = cert.get('level', 'mentioned')
            conn.execute("INSERT INTO requirements (job_id, certification, requirement_level) VALUES (?, ?, ?)",
                         (job_record['job_id'], cert['name'], level))
        conn.commit()