import requests
from bs4 import BeautifulSoup
import re

# Added a more comprehensive list
CERT_REGEX = {
    "PMP": r"pmp|project management professional|pmbok",
    "Agile/Scrum": r"agile|scrum|safe|kanban|lean",
    "ITIL": r"itil|information technology infrastructure library",
    "CISSP": r"cissp|certified information systems security professional",
    "AWS": r"aws|amazon web services",
    "Azure": r"azure|az-104|az-900",
    "Data Science/Analytics": r"data science|predictive analytics|modelling|data analysis",
    "Python/R": r"python| r ", # Added spaces around 'r' to avoid matching 'r' in other words
    "Cloud Platforms": r"databricks|rstudio|aws|azure|gcp|google cloud",
    "Geospatial": r"geospatial|gis|arcgis|qgis",
    "AI/ML": r"machine learning|artificial intelligence|deep learning|neural networks|llm|inference|nlp|natural language processing",
    "Business Analysis": r"cbap|pmi-pba|business analysis",
    "Data Tools": r"power bi|snowflake|sql|tableau|sas"
}

import requests
from bs4 import BeautifulSoup

def fetch_url(url):
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"}
    try:
        response = requests.get(url, headers=headers, timeout=10)
        if response.status_code == 200:
            return True, response.text # Return Success + Content
        else:
            return False, f"Status Code: {response.status_code}"
    except Exception as e:
        return False, str(e)

def extract_from_html(html_content):
    soup = BeautifulSoup(html_content, "html.parser")
    # Keep the text as is (don't force lowercase here if you want to use IGNORECASE)
    text = soup.get_text(separator=" ")
    text = " ".join(text.split()) 
    
    found_certs = []
    seen = set()
    
    for cert, pattern in CERT_REGEX.items():
        # re.IGNORECASE makes sure 'PMP' matches 'pmp' or 'PMP'
        match = re.search(pattern, text, re.IGNORECASE) 
        print(f"Checking {cert}: Found? {bool(match)}") 
        
        if match:
            if cert not in seen:
                found_certs.append({"name": cert, "level": "mentioned"})
                seen.add(cert)
    return found_certs