import streamlit as st
import pandas as pd
from scraper_llm import extract_with_llm
from db_utils import init_db, save_job_data

init_db()

st.set_page_config(page_title="AI Skill Discovery", layout="wide")
st.title("🤖 AI-Powered Skill Discovery")

input_type = st.radio("Input method:", ["URL", "Paste Text"])

if input_type == "URL":
    jd_input = st.text_input("Paste Job URL:")
else:
    jd_input = st.text_area("Paste Job Description Text:", height=300)

if st.button("Analyze with AI"):
    if jd_input:
        with st.spinner("AI is analyzing..."):
            try:
                results = extract_with_llm(jd_input) 
                st.json(results)
               
                
                # We can add a 'Save' button that saves to the SAME database
                if st.button("Save to Dashboard Database"):
                    job_record = {"job_id": f"AI_{pd.Timestamp.now().strftime('%Y%m%d%H%M%S')}", 
                                  "title": "AI Research", "url": "N/A"}
                    # Ensure results is a list of dicts with 'name' and 'level'
                    save_job_data(job_record, results)
                    st.success("Saved to database! Check the main Dashboard to see it.")
            except Exception as e:
                st.error(f"Error: {e}")